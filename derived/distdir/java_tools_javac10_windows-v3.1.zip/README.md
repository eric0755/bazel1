This Java tools version was built from the bazel repository at commit hash b0317496ce596a36eea8f95d3af650a74d6a29d5
using bazel version 0.24.1.
To build from source the same zip run the commands:

$ git clone https://github.com/bazelbuild/bazel.git
$ git checkout b0317496ce596a36eea8f95d3af650a74d6a29d5
$ bazel build //src:java_tools_java10.zip
